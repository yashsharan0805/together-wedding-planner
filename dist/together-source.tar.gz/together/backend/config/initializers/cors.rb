# Copyright (C) 2024-2025 LibreWeddingPlanner contributors

# config/initializers/cors.rb

Rails.application.config.middleware.insert_before 0, Rack::Cors do
    allow do
      origins '*'
      resource '*', headers: :any, methods: [:get, :post, :patch, :put, :delete]
    end
  end